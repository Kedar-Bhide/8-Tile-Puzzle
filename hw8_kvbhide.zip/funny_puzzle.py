import copy
import heapq


def manhattan(p1, p2):
    return abs(p1[0] - p2[0]) + abs(p1[1] - p2[1])


def compute_h(state):
    h_val = 0
    puzzle = []
    for row in range(3):
        for col in range(3):
            puzzle.append([row, col])
    for tile in range(9):
        if state[tile] != 0:
            if state[tile] % 3 == 0:
                row = state[tile] // 3 - 1
                col = state[tile] % 3 + 2
            else:
                row = state[tile] // 3
                col = state[tile] % 3 - 1
            h_val += manhattan(puzzle[tile], [row, col])
    return h_val


def success(updated_puzzle):
    output = []
    for row in range(3):
        for col in range(3):
            output.append(updated_puzzle[row][col])
    return output


def successor_state(state):
    puzzle = [state[0:3], state[3:6], state[6:9]]
    for row in range(3):
        for col in range(3):
            if puzzle[row][col] == 0:
                empty_row = row
                empty_col = col
    successors = []
    if empty_row != 0:
        move_up = copy.deepcopy(puzzle)
        move_up[empty_row][empty_col] = move_up[empty_row - 1][empty_col]
        move_up[empty_row - 1][empty_col] = 0
        successors.append(success(move_up))
    if empty_row != 2:
        move_down = copy.deepcopy(puzzle)
        move_down[empty_row][empty_col] = move_down[empty_row + 1][empty_col]
        move_down[empty_row + 1][empty_col] = 0
        successors.append(success(move_down))
    if empty_col != 0:
        move_left = copy.deepcopy(puzzle)
        move_left[empty_row][empty_col] = move_left[empty_row][empty_col - 1]
        move_left[empty_row][empty_col - 1] = 0
        successors.append(success(move_left))
    if empty_col != 2:
        move_right = copy.deepcopy(puzzle)
        move_right[empty_row][empty_col] = move_right[empty_row][empty_col + 1]
        move_right[empty_row][empty_col + 1] = 0
        successors.append(success(move_right))
    return sorted(successors)


def print_succ(state):
    successors = successor_state(state)
    for i in range(len(successors)):
        h = compute_h(successors[i])
        print(successors[i], 'h={}'.format(h))
    return


def parent(parent_index, closed):
    for i in range(len(closed)):
        if closed[i][2][2] + 1 == parent_index:
            break
    return closed[i]


def print_solution(pop, closed):
    moves = 0
    poped = copy.deepcopy(pop)
    if poped[2][2] != -1:
        moves = print_solution(parent(poped[2][2], closed), closed)
    h = compute_h(poped[1])
    print(poped[1], 'h={}'.format(h), 'moves: {}'.format(moves))
    return moves + 1


def solve(state):
    open = []
    closed = []
    h = compute_h(state)
    g = 0
    heapq.heappush(open, (g + h, state, (g, h, -1)))
    if len(open) == 0:
        return
    else:
        while True:
            heapq.heapify(open)
            pop = heapq.heappop(open)
            closed.append(pop)
            if pop[2][1] == 0:
                print_solution(pop, closed)
                return
            successors = successor_state(pop[1])
            g_succ = pop[2][0] + 1
            for successor in successors:
                present = False
                h_succ = compute_h(successor)
                for j in range(len(closed)):
                    if closed[j][1] == successor:
                        present = True
                        if closed[j][2][0] > g_succ:
                            present = False
                        else:
                            continue
                        break
                for j in range(len(open)):
                    if open[j][1] == successor:
                        present = True
                        if open[j][2][0] > g_succ:
                            open.pop(j)
                            heapq.heapify(open)
                            present = False
                        else:
                            continue
                        break
                if not present:
                    heapq.heappush(open, (g_succ + h_succ, successor, (g_succ, h_succ, pop[2][2] + 1)))
